# my_library/__init__.py

from .module import say_hello, LoanPredictor
