#My Library
A pYTHON LIBRARY for loan prediction and more.
##Installation
You can install the library using pip:
```sh
pip install my_library